#!/bin/bash

wget https://s3.amazonaws.com/research.metamind.io/wikitext/wikitext-2-raw-v1.zip
