import gguf

# TODO: add tests


def test_write_gguf():
    pass
