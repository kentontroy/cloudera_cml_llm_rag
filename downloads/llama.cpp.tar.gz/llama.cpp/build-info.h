#ifndef BUILD_INFO_H
#define BUILD_INFO_H

#define BUILD_NUMBER 1185
#define BUILD_COMMIT "9912b9e"
#endif // BUILD_INFO_H
